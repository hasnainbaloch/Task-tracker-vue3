<template>
	<button @click="onClick()" :style="{ background: color }">{{ text }}</button>
</template>

<script>
export default {
	name: "CustomButton",
	props: {
		text: String,
		color: String,
	},
	methods: {
		onClick() {
			this.$emit("on-click");
		},
	},
};
</script>

<style scope>
button{
	width: 80px;
	border: 0;
	color: cornsilk;
	height: 30px;
	border-radius: 5px;
}
</style>