<template>
  <header>
    {{ title }}
		<CustomButton :text="show ? 'Hide Form' : 'Add Task'" color="green" @on-click="$emit('addNewTask')"/>
  </header>
</template>

<script>
import CustomButton from "./CustomButton.vue";
export default {
  name: "Header",
  props: {
    title: String,
    show: Boolean
  },
	components:{CustomButton},
  emits:['addNewTask']
};
</script>

<style scoped>
header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  background: grey;
  color: white;
  padding: 20px;
}
</style>