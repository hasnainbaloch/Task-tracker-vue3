<template>

<div v-for="(task ,i) in allTasks" :key="i">
	<Task 
		@toggle-reminder="$emit('toggle-reminder', task.id)"  
		@task-del="deleteTask(task.id)" 
		:task="task"
	/>
</div>
</template>

<script>
import Task from "./Task.vue";
export default {
  name: "Tasks",
	components:{
		Task,
	},
  props: ['allTasks'],
	methods:{
		deleteTask(id){
			this.$emit('task-del', id);
		}
	},
	emits:['task-del', 'toggle-reminder']
};
</script>

<style>
</style>