<template>
  <div @dblclick="$emit('toggle-reminder')" :class="['task', task.reminder && 'reminder']">
    <h3>
      {{ task.text }}
      <span class="delete" @click="deleteTask"> Delete </span>
    </h3>
    <p>{{ task.day }}</p>
  </div>
</template>

<script>
export default {
  name: "Task",
  props: {
    task: Object,
  },
  methods:{
    deleteTask(){
      this.$emit('task-del');
    }
  },
};
</script>

<style scoped>
.task {
  background: #f4f4f4;
  margin: 5px;
  padding: 10px 20px;
  cursor: pointer;
  border-left: 5px solid rgb(228, 228, 228);
}

.reminder {
  border-left: 5px solid green;
}
.delete {
  padding: 5px;
}
.delete:hover {
  background: crimson;
  color: #fafafa;
  border-radius: 2px;
  box-shadow: 0 1px 3px 1px rgb(41, 31, 26),
              0 1px 3px 1px rgb(255, 94, 0)
              ;
}

h3 {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style>