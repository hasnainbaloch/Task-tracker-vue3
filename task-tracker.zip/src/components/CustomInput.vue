<template>
  <label class="input-control">
    <div>{{ label }}</div>
    <input
      :type="type"
      :placeholder="placeholder"
      :name="inputName"
      v-model="inputValue"
    />
  </label>
  <br />
</template>

<script>
export default {
  name: "CustomInput",
  props: [
		"type", 
		"placeholder", 
		"inputName", 
		"label", 
		"modelValue"
		],
  computed: {
    inputValue: {
      get() {
        return this.modelValue;
      },
      set(value) {
        this.$emit('update:modelValue', value)
      },
    },
  },
};
</script>

<style>
.input-control {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}
</style>