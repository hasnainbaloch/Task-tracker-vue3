<template>
  <form @submit.prevent="submitTask">
	<CustomInput 
		v-for="(input ,i) in inputs" 
		:key="i"
		:type="input.type"
		:placeholder="input?.placeholder ?? ''"
		:label="input.label"
		:inputName="input.name"
		v-model="input.value"
	/>
	<CustomIButton text="Submit" color="grey" />
  </form>
</template>

<script>
import CustomInput from './CustomInput.vue';
import CustomIButton from './CustomButton.vue';

export default {
	
	name: "AddTask",
	components: {
		CustomInput,
		CustomIButton,
	},
	data(){
		return{
			inputs:[
				{
					label: 'Task',
					type: 'text',
					placeholder: 'Add Task',
					name: 'task',
					value: null
				},
				{
					label: 'Date and Time',
					type: 'datetime-local',
					name: 'day',
					value: null
				},
				{
					label: 'Set Reminder',
					type: 'checkbox',
					name: 'reminder',
					value: null
				},
				
			]
		}
	},
	methods:{
		submitTask(){
			this.$emit('taskSubmitted', this.inputs)
		}
	}
};
</script>

<style>
</style>