<template>
  <Header title="Task Tracker" @addNewTask="isNewTask" :show="show"/>
  <AddTask v-if="show" @taskSubmitted="addTaskHandler" />
  <Tasks
    @task-del="deleteTask"
    @toggle-reminder="toggleReminder"
    :allTasks="tasks"
  />
  <p v-if="!show && tasks.length === 0" style="textAlign: center"> Create Task!</p>
</template>

<script>
import HelloWorld from "./components/HelloWorld.vue";
import Header from "./components/Header.vue";
import Tasks from "./components/Tasks.vue";
import AddTask from "./components/AddTask.vue";

export default {
  name: "App",
  components: {
    HelloWorld,
    Header,
    Tasks,
    AddTask,
  },
  methods: {
    deleteTask(id) {
      this.tasks = this.tasks.filter((item) => item.id !== id);
    },

    toggleReminder(id) {
      this.tasks = this.tasks.map((item) =>
        item.id === id ? { ...item, reminder: !item.reminder } : item
      );
    },

    addTaskHandler(rec) {
      this.newTask = {
        id: this.tasks.length,
        text: rec[0]?.value ?? "",
        day: new Date(rec[1]?.value).toUTCString() ?? "",
        reminder: rec[2].value ?? false,
      };
      this.tasks.push(this.newTask);
      // this.show = false;

    },
    
    isNewTask() {
      this.show = !this.show;
    },
  },

  data() {
    return {
      tasks: [],
      newTask: {},
      show: false,
    };
  },
  created() {
    this.tasks = [
      {
        id: "1",
        text: "Doctor Appointment",
        day: "Dec 1st at 6:00pm",
        reminder: true,
      },
      {
        id: "2",
        text: "Interview",
        day: "Dec 8th at 10:00pm",
        reminder: false,
      },
      {
        id: "3",
        text: "Travelling",
        day: "Dec 2nd at 10:00pm",
        reminder: true,
      },
    ];
  },
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
</style>
